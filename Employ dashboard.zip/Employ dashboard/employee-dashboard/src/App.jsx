import { useEffect, useState } from 'react';
import { Routes, Route, Link, useNavigate } from 'react-router-dom';
import './App.css';

function Dashboard({ newEmployees }) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    setLoading(false);
    setError('');
  }, [newEmployees]);

  const allEmployees = [...newEmployees];

  return (
    <div className="dashboard">
      <div className="dashboard-header">
        <div>
          <h2>Employee Dashboard</h2>
          <p className="subtitle">Employee Management System</p>
        </div>
      </div>

      <div className="dashboard-heading">
        <h3>Employee List</h3>
        <Link to="/employee-form" className="add-button">
          + Add Employee
        </Link>
      </div>

      {loading && <p>Loading employees...</p>}
      {error && <p className="error-message">{error}</p>}

      {!loading && !error && (
        <div className="table-wrapper">
          <table>
            <thead>
              <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Designation</th>
                <th>Location</th>
                <th>Salary</th>
              </tr>
            </thead>
            <tbody>
              {allEmployees.length === 0 ? (
                <tr>
                  <td colSpan="6">No employees added yet.</td>
                </tr>
              ) : (
                allEmployees.map((emp) => (
                  <tr key={emp.id}>
                    <td>{emp.id}</td>
                    <td>{emp.name}</td>
                    <td>{emp.email || '-'}</td>
                    <td>{emp.designation}</td>
                    <td>{emp.location}</td>
                    <td>{emp.salary}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

function EmployeeForm({ addEmployee }) {
  const navigate = useNavigate();

  const [form, setForm] = useState({
    name: '',
    designation: '',
    location: '',
    salary: ''
  });

  function handleChange(event) {
    const { name, value } = event.target;
    setForm((previous) => ({ ...previous, [name]: value }));
  }

  function handleSubmit(event) {
    event.preventDefault();

    addEmployee({
      ...form,
      id: Date.now(),
      email: '-'
    });

    alert('Employee added successfully!');

    navigate('/');
  }

  function handleCancel() {
    setForm({
      name: '',
      designation: '',
      location: '',
      salary: ''
    });
    navigate('/');
  }

  return (
    <div className="form-container">
      <h2 className="form-title">New Employee</h2>

      <form onSubmit={handleSubmit}>
        <div className="form-row">
          <label htmlFor="name">Name</label>
          <input
            id="name"
            name="name"
            type="text"
            value={form.name}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-row">
          <label htmlFor="designation">Designation</label>
          <input
            id="designation"
            name="designation"
            type="text"
            value={form.designation}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-row">
          <label htmlFor="location">Location</label>
          <input
            id="location"
            name="location"
            type="text"
            value={form.location}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-row">
          <label htmlFor="salary">Salary</label>
          <input
            id="salary"
            name="salary"
            type="number"
            min="0"
            value={form.salary}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-buttons">
          <button type="submit" className="submit-button">
            Submit
          </button>

          <button
            type="button"
            className="cancel-button"
            onClick={handleCancel}
          >
            Cancel
          </button>
        </div>
      </form>
    </div>
  );
}

export default function App() {
  const [newEmployees, setNewEmployees] = useState([]);

  function addEmployee(employee) {
    setNewEmployees((previous) => [employee, ...previous]);
  }

  return (
    <>
      <nav className="top-navbar">
        <Link className="brand" to="/">
          Employee Management
        </Link>

        <div className="nav-links">
          <Link className="nav-item" to="/">
            Home
          </Link>
          <Link className="nav-item" to="/employee-form">
            Add Employee
          </Link>
        </div>
      </nav>

      <Routes>
        <Route path="/" element={<Dashboard newEmployees={newEmployees} />} />
        <Route
          path="/employee-form"
          element={<EmployeeForm addEmployee={addEmployee} />}
        />
      </Routes>
    </>
  );
}
